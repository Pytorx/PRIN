public class Kundenliste
{
    Kunde erster = null; //Referenz (Verweis) auf den ersten Kunden in der Liste
    int anzahl; //Anzahl der Kunden in der Liste

    public Kundenliste()
    {
        erster = null;
        anzahl = 0;
    }

    public int getAnzahl()
    {
        return anzahl;
    }
    
    
    public void einfuegenAnfang(Kunde neukunde)
    {
        neukunde.setNachfolger(erster);
        erster = neukunde;
        anzahl++;
    }
    
    
    public void einfuegenEnde(Kunde neukunde)
    {       
        if(erster == null)
        {
            erster = neukunde;
            anzahl++;
            return;
        }
    
        Kunde kunde = erster; //zum Zwischenspeichern der Objektreferenz

        /*  Die folgende Schleife wird erst verlassen, wenn in kunde die
        Referenz auf den letzten Kunden der Liste gespeichert ist */

        while(kunde.getNachfolger() != null)
        {
            kunde = kunde.getNachfolger();
        }

        kunde.setNachfolger(neukunde); // Referenz vom urspr�nglich letzten Kunde auf den neuen letzten Kunden setzen
        anzahl++;
    }
    
    public Kunde suchen(int kundennummer)
    {
        if(erster == null)
        {
            return null;
        }
        
        Kunde kunde = erster;

        do
        {
            if (kunde.getNummer() == kundennummer) 
            {
                return kunde;
            }
            
            kunde = kunde.getNachfolger();
        }
        while(kunde != null);
    
        return null;
    }
    
    
    public boolean loeschen(int kundennummer)
    {
        if(suchen(kundennummer) == null)
        {
            return false;
        }
    
        if(erster.getNummer() == kundennummer)
        {
            erster = erster.getNachfolger();
            anzahl--;
            return true;
        }
    
        Kunde vorgaenger = erster;
        Kunde kunde = erster.getNachfolger();
        
        do
        {
            if (kunde.getNummer() == kundennummer) 
            {
                vorgaenger.setNachfolger(kunde.getNachfolger());
                anzahl--;
                return true;
            }
            
            vorgaenger = kunde;
            kunde = kunde.getNachfolger();
        }
        while(kunde != null);
    
        return false;
    }    
    
    /*   
    //diese Methode existiert nur fuer Testzwecke und kann spaeter entfernt werden
    public void erzeugenTestliste()
    {
        Kunde kunde1 = new Kunde(4711, "Meier");
        Kunde kunde2 = new Kunde(4766, "Lehmann");
        Kunde kunde3 = new Kunde(4722, "Schulze");
        erster = kunde1;
        kunde1.setNachfolger(kunde2);
        kunde2.setNachfolger(kunde3);
        
    }
    */
    
    //diese Methode existiert nur fuer Testzwecke und kann spaeter entfernt werden
    public void ausgebenTestliste()
    {
        if(erster == null)
        {
            return;
        }
    
        Kunde kunde = erster;

        do
        {
            System.out.println(kunde.getNummer() + " " + kunde.getNachname());
            kunde = kunde.getNachfolger();
        }
        while(kunde != null);
    }
}
