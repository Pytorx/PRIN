public class TestMain
{
    public static void main (String args[])
    {
        Kundenliste kundenliste = new Kundenliste();
        //kundenliste.erzeugenTestliste();
               
        Kunde kunde1 = new Kunde(4711, "Meier");
        Kunde kunde2 = new Kunde(4766, "Lehmann");
        Kunde kunde3 = new Kunde(4722, "Schulze");
               
        kundenliste.einfuegenEnde(kunde1);
        kundenliste.einfuegenAnfang(kunde2);
        kundenliste.einfuegenEnde(kunde3);
        
        System.out.println("Anzahl: " + kundenliste.getAnzahl());
        
        kundenliste.ausgebenTestliste();
        
        Kunde kunde = kundenliste.suchen(4721);
        
        if(kunde != null)
        {
            System.out.println(kunde.getNachname());
        }
           else 
           {
                System.out.println("Kunde existiert nicht!");   
           }                                         
        
        System.out.println("\n geloescht: " + kundenliste.loeschen(3333));
        
        System.out.println("\n geloescht: " + kundenliste.loeschen(4711));
        System.out.println("Anzahl: " + kundenliste.getAnzahl());
        kundenliste.ausgebenTestliste();
        
        System.out.println("\n geloescht: " + kundenliste.loeschen(4722));
        System.out.println("\n geloescht: " + kundenliste.loeschen(4766));
        System.out.println("Anzahl: " + kundenliste.getAnzahl());
        kundenliste.ausgebenTestliste();
        
    }
}



