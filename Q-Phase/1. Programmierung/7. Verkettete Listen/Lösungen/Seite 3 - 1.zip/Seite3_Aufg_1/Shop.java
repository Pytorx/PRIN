public class Shop
{
    private Bestellung erste, letzte; 
    int anzahl;

    public Shop()
    {
        erste = null;
        letzte = null;
        anzahl = 0;
    }

    public int size()
    {
        return anzahl;
    }

    public void anhaengenBestellung(Bestellung neuBestellung)
    {
        anzahl++;

        if(erste == null)
        {
            erste = neuBestellung;
            letzte = erste;
        }
            else
            {
                letzte.setNachfolger(neuBestellung);
                letzte = neuBestellung;
            }
    }

    public Bestellung herausholenBestellung()
    {
        if(erste == null)
        {
            return null;
        }

        anzahl--;
        Bestellung bestellung = erste;
        erste = erste.getNachfolger();
        bestellung.setNachfolger(null);
        return bestellung;
    }
}

