public class Bestellung
{
	private double preis;
	private Kunde kunde;
	private Bestellung nachfolger;

	public Bestellung(double preis, Kunde kunde)
	{
		this.preis = preis;
		this.kunde = kunde;
	}

	public double getPreis()
	{
		return preis;
	}

	public Kunde getKunde()
	{
		return kunde;
	}

	public Bestellung getNachfolger()
	{
		return nachfolger;
	}

	public void setNachfolger(Bestellung bestellung)
	{
		this.nachfolger = bestellung;
	}
}
