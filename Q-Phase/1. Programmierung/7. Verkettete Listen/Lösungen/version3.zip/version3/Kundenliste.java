public class Kundenliste
{
    Kunde erster = null; //Referenz (Verweis) auf den ersten Kunden in der Liste
       
    //diese Methode existiert nur fuer Testzwecke und kann spaeter entfernt werden
    public void erzeugenTestliste()
    {
        Kunde kunde1 = new Kunde(4711, "Meier");
        Kunde kunde2 = new Kunde(4766, "Lehmann");
        Kunde kunde3 = new Kunde(4722, "Schulze");
        erster = kunde1;
        kunde1.setNachfolger(kunde2);
        kunde2.setNachfolger(kunde3);
        
    }
    
    //diese Methode existiert nur fuer Testzwecke und kann spaeter entfernt werden
    public void ausgebenTestliste()
    {
        if(erster == null)
        {
            return;
        }
    
        Kunde kunde = erster;

        do
        {
            System.out.println(kunde.getNummer() + " " + kunde.getNachname());
            kunde = kunde.getNachfolger();
        }
        while(kunde != null);
    }
}
