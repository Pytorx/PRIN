public class TestMain
{
    public static void main (String args[])
    {
        Kundenliste kundenliste = new Kundenliste();
        kundenliste.erzeugenTestliste();
        kundenliste.ausgebenTestliste();
    }
}



