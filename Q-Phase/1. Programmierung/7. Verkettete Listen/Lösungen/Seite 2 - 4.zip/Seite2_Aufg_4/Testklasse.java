

public class Testklasse
{
	public static void ausgebenBestellungsdaten(Bestellung bestellung)
	{
		if(bestellung == null)
		{
			System.out.println("Liste leer!");
			return;
		}

		Kunde kunde = bestellung.getKunde();
		double preis = bestellung.getPreis();
		System.out.println("Preis: " + preis + "   Kundennummer: " + kunde.getNummer() + "   Kundennachname: " + kunde.getNachname() );
	}

	public static void main (String args[])
	{
		Shop shop = new Shop();

		Kunde k1 = new Kunde(1001, "Meier");
		Kunde k2 = new Kunde(1002, "Schulze");
		Kunde k3 = new Kunde(1003, "Lehmann");

		Bestellung bestellung1 = new Bestellung(23.56 , k1);
		Bestellung bestellung2 = new Bestellung(39.99 , k2);
		Bestellung bestellung3 = new Bestellung(45.66 , k3);
		Bestellung bestellung4 = new Bestellung(62.44 , k3);

		//1. Test (leere Liste, 1 raus)
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		System.out.println("---------------------------- Ende des 1. Tests --------------\n\n");


		//2. Test (1 rein, 2 raus)
		shop.anhaengenBestellung(bestellung1);
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		System.out.println("---------------------------- Ende des 2. Tests --------------\n\n");


		//3. Test (3 rein, 3 raus)
		shop.anhaengenBestellung(bestellung1);
		shop.anhaengenBestellung(bestellung2);
		shop.anhaengenBestellung(bestellung3);
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		System.out.println("---------------------------- Ende des 3. Tests --------------\n\n");


		//4. Test: rein/raus durcheinander
		shop.anhaengenBestellung(bestellung1);
		shop.anhaengenBestellung(bestellung2);
		shop.anhaengenBestellung(bestellung3);
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		shop.anhaengenBestellung(bestellung4);
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		ausgebenBestellungsdaten(shop.herausholenBestellung());
		System.out.println("---------------------------- Ende des 4. Tests --------------\n\n");
	}
}
