public class Kunde
{
	private int nummer;
	private String nachname;

	public Kunde(int nummer, String nachname)
	{
		this.nummer = nummer;
		this.nachname = nachname;
	}

	public int getNummer()
	{
		return nummer;
	}

	public String getNachname()
	{
		return nachname;
	}
}
