public class Shop
{
	Bestellung erste; //Referenz (Verweis) auf die 1. Bestellung
	int anzahl; //Anzahl der Bestellungen in der Liste

	public Shop()
	{
		erste = null;
		anzahl = 0;
	}

	public int size()
	{
		return anzahl;
	}

	public void anhaengenBestellung(Bestellung neuBestellung)
	{
		anzahl++;

		if(erste == null)
		{
			erste = neuBestellung;
		}
			else
			{
				Bestellung bestellung = erste;

				while(bestellung.getNachfolger() != null)
				{
					bestellung = bestellung.getNachfolger();
				}

				bestellung.setNachfolger(neuBestellung);
			}
	}

	public Bestellung herausholenBestellung()
	{
		if(erste == null)
		{
			return null;
		}

		anzahl--;
		Bestellung bestellung = erste;
		erste = erste.getNachfolger();
		bestellung.setNachfolger(null);
		return bestellung;
	}
}

