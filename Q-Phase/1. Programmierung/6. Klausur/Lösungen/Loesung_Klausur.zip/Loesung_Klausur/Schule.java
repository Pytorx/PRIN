import java.util.*;                                                                            //darf fehlen

public class Schule 
{
    private ArrayList<Lehrer> lehrerListe = new ArrayList<Lehrer>();                           //   2
    private ArrayList<Schueler> schuelerListe = new ArrayList<Schueler>();
    
    public Lehrer suchenLehrer1(String id)                                                        //   4
    {
        for (Lehrer lehrer: lehrerListe)
        {
            if(lehrer.getId().equals(id))
            {
                return lehrer;
            }
        }
        
        return null;          
    }      
    
    public ArrayList<Lehrer> suchenLehrer2(String fach)                                        // 5
    {
        ArrayList<Lehrer> trefferListe = new ArrayList<Lehrer>();
        
        for (Lehrer lehrer: lehrerListe)
        {
            if(lehrer.getId().equals(fach))
            {
                trefferListe.add(lehrer);
            }
        }
        
        return trefferListe;          
    }      
    
    
    
    
} // end of Schule

