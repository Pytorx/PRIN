import java.util.*;                                                                            //darf fehlen

public class SchuleNachschreiber 
{
    private ArrayList<Lehrer> lehrerListe = new ArrayList<Lehrer>();                           //   2
    private ArrayList<Schueler> schuelerListe = new ArrayList<Schueler>();
    
    public Lehrer suchenLehrer1(String id)                                                        //   4
    {
        for (Lehrer lehrer: lehrerListe)
        {
            if(lehrer.getId().equals(id))
            {
                return lehrer;
            }
        }
        
        return null;          
    }      
    
    public ArrayList<Lehrer> suchenLehrer2(String fach)                                        // 5
    {
        ArrayList<Lehrer> trefferListe = new ArrayList<Lehrer>();
        
        for (Lehrer lehrer: lehrerListe)
        {
            if(lehrer.getFach().equals(fach))
            {
                trefferListe.add(lehrer);
            }
        }
        
        return trefferListe;          
    }      
    
    public boolean loeschenLehrer(String id)                                                    // 5
    {
        Lehrer lehrer = suchenLehrer1(id);   //Die Verwendung von suchenLehrer1(id) ist nicht zwingend erforderlich, verk�rzt aber den Code.
        
        if(lehrer == null)
        {
            return false;
        }
        
        return lehrerListe.remove(lehrer);
    }
    
}

