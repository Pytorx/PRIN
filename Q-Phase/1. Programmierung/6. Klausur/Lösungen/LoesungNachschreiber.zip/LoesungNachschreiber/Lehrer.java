public class Lehrer extends Person                                                             
{                                                                                              
    // Anfang Attribute                                                                  
    private String id;                                                                   //    2 P
    private String fach;
    // Ende Attribute
    

    

    public Lehrer(String vorname, String nachname, Adresse adresse, String id, String fach)         //  2 P
    {
        super(vorname, nachname, adresse);
        this.id = id;
        this.fach = fach;
       
  
    }

    // Anfang Methoden
 
    public String getId() {                                                                //       1 P
        return id;
    }


    public String getFach() 
    {
        return fach;                                                                       //       1 P
    }

   
    // Ende Methoden

    
} 

