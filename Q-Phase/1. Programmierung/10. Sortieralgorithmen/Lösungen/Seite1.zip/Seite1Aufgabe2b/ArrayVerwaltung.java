
public class ArrayVerwaltung
{
    public int[] sortieren(int[] werte)
    {
        int maxIndex = werte.length - 1;    // (momentaner) hoechster Index im unsortierten Teil des Arrays
        int temp;                           // Variable f�r das Zwischenspeichern beim Tauschen
        boolean getauscht;                  // zum registrieren eines Tauschvorganges
               
        // Bubblesort durchfuehren, solange der unsortierte Teil des Arrays mehr als ein Element enth�lt
        while(maxIndex > 0 )
        {
            getauscht = false;

            // unsortierter Teil des Arrays wird duchlaufen
            for(int i = 0; i < maxIndex; i++)
            {
                if(werte[i] > werte[i+1])
                {
                    //Tauschvorgang
                    temp = werte[i+1];
                    werte[i+1] = werte[i];
                    werte[i] = temp;
                    getauscht = true;
                }
            }

            // wenn innerhalb eines Duchlaufs kein Tauschvorgang stattgefunden hat,
            // so ist das Array sortiert --> vorzeitiger Abbruch des Bubblesorts
            if(getauscht == false)
            {
                break;
            }

            maxIndex--; // unsortierter Teil des Arrays wird um 1 Element verkuerzt
        }
        
        return werte;        
    }
}
