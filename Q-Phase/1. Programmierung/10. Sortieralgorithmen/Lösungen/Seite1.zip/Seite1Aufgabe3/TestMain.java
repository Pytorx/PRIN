
public class TestMain
{
    public static void main (String args[])
    { 
        Kunde[] kunden = new Kunde[5];
        
        kunden[0] = new Kunde(45, "Meier", "Otto");
        kunden[1] = new Kunde(33, "Schulze", "Erna");
        kunden[2] = new Kunde(41, "Meier", "Sabine");
        kunden[3] = new Kunde(29, "Maier", "Sabine");
        kunden[4] = new Kunde(43, "Lehmann", "Olaf");
        
        ArrayVerwaltung arrayVerwaltung = new ArrayVerwaltung();
        
        kunden = arrayVerwaltung.sortieren(kunden);    
        
        for (int i=0; i<kunden.length; i++) 
        {
            System.out.println(kunden[i].getKundennummer() + "  " + kunden[i].getNachname() + "  " + kunden[i].getVorname() + "  ");
        }      
    }   
}
