/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 19.01.2024
 * @author 
 */

public class Kunde {
    
    // Anfang Attribute
    private int kundennummer;
    private String nachname;
    private String vorname;
    // Ende Attribute
    
    public Kunde(int kundennummer, String nachname, String vorname) {
        this.kundennummer = kundennummer;
        this.nachname = nachname;
        this.vorname = vorname;
    }

    // Anfang Methoden
    public int getKundennummer() {
        return kundennummer;
    }

    public String getNachname() {
        return nachname;
    }

    public String getVorname() {
        return vorname;
    }

    // Ende Methoden
} // end of Kunde

