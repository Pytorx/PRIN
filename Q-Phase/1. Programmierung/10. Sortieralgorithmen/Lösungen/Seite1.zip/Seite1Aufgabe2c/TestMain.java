
public class TestMain
{
    public static void main (String args[])
    {
        int[] werte = {5,2,9,6,7,1};
        
        ArrayVerwaltung arrayVerwaltung = new ArrayVerwaltung();
        
        int[] werteSortiert = arrayVerwaltung.sortieren(werte, false);    
        
        for (int i=0; i<werteSortiert.length; i++) 
        {
            System.out.print(werteSortiert[i] + "  ");
        } 
        
   
        
    }   
}
