
public class Sortierer //Quicksort
{

    private static int[] a;


    public void quicksort(int feld[])
    {
        a = feld;

        System.out.println("Anfangszustand:");
        anzeigen(a);
        sortieren (0,feld.length-1);
        System.out.println("\nEndzustand:");
        anzeigen(a);
    }

    public void sortieren(int links, int rechts)
    {
        int i=links, k=rechts;
        int pivot=a[(links+rechts)/2];

        while (i<=k)
        {
            while (a[i]<pivot)
            {i++;}
            while (a[k]>pivot)
            {k--;}

            if (i<=k)
            {
               anzeigen2(a,i,k,pivot);
               tauschen(i, k);
               i++;
               k--;
            }
        }

        // REKURSION (Methode ruft sich selbst auf)
        if (links<k)
        {
            System.out.println();
            sortieren(links, k);
        }
        if (i<rechts)
        {
            System.out.println();
            sortieren(i, rechts);
        }

    }

    public void tauschen (int i, int k)
    {
        int temp=a[i];
        a[i]=a[k];
        a[k]=temp;
    }

    public void anzeigen(int feld[])
    {
        int anzahl = feld.length;

        for(int i=0 ; i < anzahl ; i++)
        {
            System.out.print(feld[i]+" ");
        }
        System.out.println("\n\n");

    }

    public void anzeigen2(int feld[], int ii, int kk, int pivot)
    {

        int anzahl = feld.length;

        for(int n=0 ; n < anzahl ; n++)
        {
            System.out.print(feld[n]+" ");
        }

        System.out.print(" pivot="+pivot+" i="+ii+" k="+kk+"\n");
    }
}
