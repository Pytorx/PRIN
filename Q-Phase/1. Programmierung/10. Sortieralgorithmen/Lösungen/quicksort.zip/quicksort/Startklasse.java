
public class Startklasse
{
    public static void main (String args[])
    {
        Sortierer sort = new Sortierer();
        int[] feld = {8,3,4,0,7,9,1,1,1,6};

        //sort.anzeigen(feld);
        sort.quicksort(feld);
        //sort.anzeigen(feld);
    }
}
