public class Waggon  //4 Punkte
{
    private String ziel;
    private double laenge;                                      //neu               Laenge in Meter
    private Waggon naechster;

    public Waggon(String ziel, double laenge)                   // z.T. neu
    {
        this.ziel = ziel;
        this.laenge = laenge;                               //neu
        this.naechster = null;
    }

    public Waggon getNaechster()
    {
        return naechster;
    }

    public void setNaechster(Waggon waggon)
    {
        this.naechster = waggon;
    }

    public String getZiel()
    {
        return ziel;
    }

    public double getLaenge()                               //neu
    {                                                       //neu
        return laenge;                                      //neu
    }                                                       //neu
}


