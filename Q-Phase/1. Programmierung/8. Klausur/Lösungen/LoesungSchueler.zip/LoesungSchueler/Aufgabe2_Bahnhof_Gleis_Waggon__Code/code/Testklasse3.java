
// Hier wird nur die Methode zaehlen getestet und sonst nix!
// Hier wird die �berschreitung der Gleisl�nge nicht getestet.
// Die entsprechenden Werte sind so zu w�hlen, dass immer alle
// Waggons auf das Gleis passen.


public class Testklasse3
{
    public static void main (String args[])
    {
        Gleis gleis = new Gleis(13, 500); // Gleis ist 200 Meter lang

        Waggon waggon1 = new Waggon("Bonn", 10);  // alles Waggons sind 10 Meter lang
        Waggon waggon2 = new Waggon("Dresden", 10);
        Waggon waggon3 = new Waggon("Bonn", 10);
        Waggon waggon4 = new Waggon("Aachen", 10);
        Waggon waggon5 = new Waggon("Bonn", 10);
      
        System.out.println(gleis.zaehlen("Bonn"));
          
        gleis.abstellen(waggon1);
        gleis.abstellen(waggon2);
        gleis.abstellen(waggon3);
        gleis.abstellen(waggon4);
        gleis.abstellen(waggon5);
        
        System.out.println(gleis.zaehlen("Bonn"));       
    }
}
