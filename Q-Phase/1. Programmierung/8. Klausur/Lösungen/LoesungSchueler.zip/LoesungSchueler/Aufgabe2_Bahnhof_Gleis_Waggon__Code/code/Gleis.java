

public class Gleis  // 6 Punkte f�r �nderungen bzgl. L�ngen und 5 Punkte f�r die komplett neue Methode zaehlen
{
    private int nummer;
    private double laengeMax;                                       //neu       L�nge in Meter!
    private double laengeBelegt;                                    //neu       L�nge in Meter!
    private Waggon letzter;

    public Gleis(int nummer, double laengeMax)                      // z.T. neu
    {
        this.nummer = nummer;
        this.laengeMax = laengeMax;                             //neu
        this.laengeBelegt = 0;
    }

    public boolean abstellen(Waggon waggon)                     // z.T. neu
    {
        if((laengeBelegt + waggon.getLaenge()) > laengeMax)     //neu
        {                                                       //neu
            return false;                                       //neu
        }                                                       //neu

        if(letzter != null)
        {
            waggon.setNaechster(letzter);
            letzter = waggon;
        }
            else
            {
                letzter = waggon;
            }

        laengeBelegt = laengeBelegt + waggon.getLaenge();       //neu
        return true;                                            //neu
    }

    public Waggon entnehmen()                                   
    {                                                           
        if(letzter != null)                                     
        {                                                       
            Waggon waggon = letzter;                            
            letzter = letzter.getNaechster();                   
            waggon.setNaechster(null);                          
            laengeBelegt = laengeBelegt - waggon.getLaenge();   //neu
            return waggon;                                      
        }                                                       
        return null;                                            
    } 
    
    //komplett neue Methode
    public int zaehlen(String ziel)
    {
        int anz = 0;
        Waggon waggon = letzter;
    
        while (waggon != null) 
        { 
            if(waggon.getZiel() == ziel)
            {
                anz++;
            }
            
            waggon = waggon.getNaechster();
        } 
        
        return anz;
    }                                                              
}


