


// Hier wird vorrangig nur die �berschreitung der Gleisl�nge getestet.


public class Testklasse2
{
	public static void main (String args[])
	{
		Gleis gleis = new Gleis(13, 40); // Gleis ist  40 Meter lang

		Waggon waggon1 = new Waggon("Aachen", 10.5);
		Waggon waggon2 = new Waggon("Bonn", 11.5);
		Waggon waggon3 = new Waggon("Cottbus", 12.5);
		Waggon waggon4 = new Waggon("Dresden", 13.5);
		Waggon waggon5 = new Waggon("Essen", 14.5);
		Waggon waggon6 = new Waggon("Fulda", 15.5);

		System.out.println("\n -------- 1. Test : rein/raus durcheinander --------");
		System.out.println(gleis.abstellen(waggon1));			//true
		System.out.println(gleis.abstellen(waggon2));			//true
		System.out.println(gleis.abstellen(waggon3));			//true
		System.out.println(gleis.entnehmen().getZiel());		//Cottbus
		System.out.println(gleis.abstellen(waggon4));			//true
		System.out.println(gleis.abstellen(waggon5));			//false
		System.out.println(gleis.entnehmen().getZiel());		//Dresden
		System.out.println(gleis.abstellen(waggon5));			//true

		System.out.println(gleis.entnehmen().getZiel());		//Essen
		System.out.println(gleis.entnehmen().getZiel());		//Bonn
		System.out.println(gleis.entnehmen().getZiel());		//Aachen
		System.out.println(gleis.entnehmen().getZiel());		//Exception erzeugt, Programm bricht ab
	}
}
