import java.util.ArrayList;

public class Bahnhof
{
	private String name;

	private ArrayList<Gleis> gleisListe;

	public Bahnhof(String name)
	{
		this.name = name;
		gleisListe = new ArrayList<Gleis>();
	}

	public void hinzufuegenGleis(Gleis gleis)
	{
		gleisListe.add(gleis);
	}
}


