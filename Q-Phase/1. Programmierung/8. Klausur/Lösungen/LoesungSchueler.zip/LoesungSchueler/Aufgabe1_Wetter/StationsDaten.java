

public class StationsDaten {
    
    // Anfang Attribute
    private double temperatur;
    private double luftfeuchte;
    private double luftdruck;
    // Ende Attribute
    
    public StationsDaten(double temperatur, double luftfeuchte, double luftdruck) {
        this.temperatur = temperatur;
        this.luftfeuchte = luftfeuchte;
        this.luftdruck = luftdruck;
    }

    // Anfang Methoden
    public double getTemperatur() {
        return temperatur;
    }

    public double getLuftfeuchte() {
        return luftfeuchte;
    }

    public double getLuftdruck() {
        return luftdruck;
    }

    // Ende Methoden
} // end of StationsDaten

