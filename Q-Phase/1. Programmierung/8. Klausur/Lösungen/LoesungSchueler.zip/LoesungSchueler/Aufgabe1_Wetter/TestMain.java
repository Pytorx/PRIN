
public class TestMain
{
    public static void main (String args[])
    {
        //Array mit Testdaten erzeugen
        double[][] testdaten = {
                                    {11.2, 45, 995},       // 0. Zeile (Station 0)
                                    {11.9, 45, 1005},      // 1. Zeile (Station 1)
                                    {11.5, 42, 995}        // 2. Zeile (Station 2)
                                };
        
        Wetterdatenverwaltung verwaltung = new Wetterdatenverwaltung();
        
        System.out.println("H�chste Temperatur: " + verwaltung.suchenMaxTemperatur(testdaten));
        
        StationsDaten daten = verwaltung.suchenStationsDaten(testdaten, 1);
        
        System.out.println("\n----- Daten der Station mit der Nummer 1 ------");
        System.out.println("Temperatur: "+ daten.getTemperatur());
        System.out.println("Luftfeuchte: " + daten.getLuftfeuchte()); 
        System.out.println("Luftdruck: " + daten.getLuftdruck()); 
    }
}
