
public class Wetterdatenverwaltung 
{
    public double suchenMaxTemperatur(double[][] datenTabelle) 
    {
        double max = -274; //weniger physikalisch nicht m�glich, alle Messwerte sind gr��er
        
        for(int i = 0; i < datenTabelle.length; i++ ) 
        {
            if(datenTabelle[i][0] > max)
            {
                max = datenTabelle[i][0];
            }  
        } 
        return max;
    }

    public StationsDaten suchenStationsDaten(double[][] datenTabelle, int nummer) 
    {
        StationsDaten daten = new StationsDaten(datenTabelle[nummer][0], datenTabelle[nummer][1], datenTabelle[nummer][2]);
        
        return daten;
    }    
} 

