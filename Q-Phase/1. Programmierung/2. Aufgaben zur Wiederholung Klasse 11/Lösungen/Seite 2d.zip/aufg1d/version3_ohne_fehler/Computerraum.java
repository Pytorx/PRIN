
public class Computerraum extends Raum
{
	private int anzahlPC;

	public Computerraum(String bezeichnung, int anzahlPlaetze, boolean waschbecken, int anzahlPC)
	{
		super(bezeichnung, anzahlPlaetze, waschbecken);
		this.anzahlPC = anzahlPC;
	}

	public void setAnzahlPC(int anzahlPC)
	{
		this.anzahlPC = anzahlPC;
	}

	public int getAnzahlPC()
	{
		return anzahlPC;
	}

	public boolean pruefenAllePlaetzeHabenPC()
	{
		return this.getAnzahlPlaetze() == this.anzahlPC;
	}
}

