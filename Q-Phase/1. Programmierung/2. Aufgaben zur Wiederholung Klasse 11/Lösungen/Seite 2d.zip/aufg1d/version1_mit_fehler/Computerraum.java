
/*
Beim Compilieren des Codes wird eine Fehlermeldung erzeugt.
Erkl�ren Sie die Fehlermeldung.
Erl�utern Sie 2 M�glichkeiten, den Fehler zu beheben und
korrigieren Sie entsprechend den Code.
*/


public class Computerraum extends Raum
{
	private int anzahlPC;

	public Computerraum(String bezeichnung, int anzahlPlaetze, boolean waschbecken, int anzahlPC)
	{
		super(bezeichnung, anzahlPlaetze, waschbecken);
		this.anzahlPC = anzahlPC;
	}

	public void setAnzahlPC(int anzahlPC)
	{
		this.anzahlPC = anzahlPC;
	}

	public int getAnzahlPC()
	{
		return anzahlPC;
	}

	public boolean pruefenAllePlaetzeHabenPC()
	{
		return this.anzahlPlaetze == this.anzahlPC;
	}
}

