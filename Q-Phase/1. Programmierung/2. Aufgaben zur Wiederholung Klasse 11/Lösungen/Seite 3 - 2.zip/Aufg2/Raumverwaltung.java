
import java.util.ArrayList;

public class Raumverwaltung
{
	public static void main (String args[])
	{
		//Liste erzeugen (Objekt der Klasse ArrayList)
		ArrayList<Raum> raumListe = new ArrayList<Raum>(200);

		//Hilfsvariablen zur Zwischenspeicherung definieren
		String bezeichnung;
		int anzahlPlaetze;
		boolean waschbecken;
		boolean beenden;

		//Objekt der Klasse Raum definieren (aber noch nicht erzeugen)
		Raum r;

		//Eingabeschleife
		while(true)
		{
			System.out.println(" \n------- Geben Sie die Daten eines Raumes ein! -------");

			System.out.print("Bezeichnung des Raums eingeben: ");
			bezeichnung = Tastatur.stringInput();

			System.out.print("Anzahl der Plaetze eingeben: ");
			anzahlPlaetze = Tastatur.intInput();

			System.out.print("Waschbecken? Geben Sie true oder false ein: ");
			waschbecken = Tastatur.booleanInput();

			//Objekt der Klasse Raum erzeugen und in der Liste speichern
			r = new Raum(bezeichnung, anzahlPlaetze, waschbecken);
			raumListe.add(r);

			System.out.print("Eingabe beenden? Geben Sie true oder false ein: ");
			beenden = Tastatur.booleanInput();

			if(beenden)
			{
				break;
			}
		}


		System.out.println("\n\n-------- RAUM SUCHEN ---------\n");

		System.out.print("Bezeichnung des Raums eingeben: ");
		bezeichnung = Tastatur.stringInput();
		boolean existiert = false;

		for(int i = 0; i < raumListe.size(); i++)
		{
			r = raumListe.get(i);

			if(r.getBezeichnung().equals(bezeichnung))
			{
				System.out.println("\n----------- Raum gefunden -------------------");
				System.out.println("Bezeichnung des Raums: " + r.getBezeichnung());
				System.out.println("Anzahl Plaetze: " + r.getAnzahlPlaetze());
				System.out.println("Waschbecken vorhanden: " + r.getWaschbecken());
				existiert = true;
			}
		}

		if(!existiert)
		{
			System.out.println("\nRaum nicht gefunden !\n");
		}
	}
}
