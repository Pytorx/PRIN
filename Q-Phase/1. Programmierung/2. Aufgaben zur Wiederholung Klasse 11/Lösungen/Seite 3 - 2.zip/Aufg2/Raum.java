public class Raum
{
	private String bezeichnung;
	private int anzahlPlaetze;
	private boolean waschbecken;

	public Raum(String bezeichnung, int anzahlPlaetze, boolean waschbecken)
	{
		this.bezeichnung = bezeichnung;
		this.anzahlPlaetze = anzahlPlaetze;
		this.waschbecken = waschbecken;
	}

	public void setBezeichnung(String bezeichnung)
	{
		this.bezeichnung = bezeichnung;
	}

	public void setAnzahlPlaetze(int anzahlPlaetze)
	{
		this.anzahlPlaetze = anzahlPlaetze;
	}

	public void setWaschbecken(boolean waschbecken)
	{
		this.waschbecken = waschbecken;
	}

	public String getBezeichnung()
	{
		return bezeichnung;
	}

	public int getAnzahlPlaetze()
	{
		return anzahlPlaetze;
	}

	public boolean getWaschbecken()
	{
		return waschbecken;
	}
}