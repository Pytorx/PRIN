/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 15.09.2023
 * @author 
 */

public class Mitarbeiter {
  
  // Anfang Attribute
  private int id;
  private String gebDatum;
  private String nachname;
  private String vorname;
  private Arbeitsvertrag arbeitsvertrag;
  // Ende Attribute
  
  public Mitarbeiter(int id, String gebDatum, String nachname, String vorname, Arbeitsvertrag arbeitsvertrag) {
    this.id = id;
    this.gebDatum = gebDatum;
    this.nachname = nachname;
    this.vorname = vorname;
    this.arbeitsvertrag = arbeitsvertrag;
  }

  // Anfang Methoden
  public int getId() {
    return id;
  }

  public String getGebDatum() {
    return gebDatum;
  }

  public String getNachname() {
    return nachname;
  }

  public String getVorname() {
    return vorname;
  }

  public Arbeitsvertrag getArbeitsvertrag() {
    return arbeitsvertrag;
  }
  
  public void setArbeitsvertrag(Arbeitsvertrag arbeitsvertrag) {
    this.arbeitsvertrag = arbeitsvertrag;
  }
  

  // Ende Methoden
} // end of Mitarbeiter

