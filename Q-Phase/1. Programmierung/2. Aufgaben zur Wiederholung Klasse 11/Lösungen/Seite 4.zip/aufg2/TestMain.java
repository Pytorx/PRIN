
public class TestMain
{
  public static void main (String args[])
  {
    Mitarbeiter mitarbeiter = new Mitarbeiter(4711, "Melitta", "Jacobs-Dallmayr", null, null);
    Arbeitsvertrag arbeitsvertrag = new Arbeitsvertrag(4711, "Kaffee kochen", 4000);
    
    mitarbeiter.setArbeitsvertrag(arbeitsvertrag);
    
    //Zugriff vom Mitarbeiter-Objekt auf das Arbeitsvertrag-Objekt , Variante 1
    Arbeitsvertrag av = mitarbeiter.getArbeitsvertrag();
    String s = av.getTaetigkeit();
    System.out.println("T�tigkeit: " + s);

    //Zugriff vom Mitarbeiter-Objekt auf das Arbeitsvertrag-Objekt , Variante 2
    System.out.println("T�tigkeit: " + mitarbeiter.getArbeitsvertrag().getTaetigkeit() );
    
    
    
   
  }
}
