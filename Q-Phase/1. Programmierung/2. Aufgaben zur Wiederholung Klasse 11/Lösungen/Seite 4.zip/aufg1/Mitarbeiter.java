/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 15.09.2023
 * @author 
 */

public class Mitarbeiter {
  
  // Anfang Attribute
  private int id;
  private String gebDatum;
  private String nachname;
  private String vorname;
  // Ende Attribute
  
  public Mitarbeiter(int id, String gebDatum, String nachname, String vorname) {
    this.id = id;
    this.gebDatum = gebDatum;
    this.nachname = nachname;
    this.vorname = vorname;
  }

  // Anfang Methoden
  public int getId() {
    return id;
  }

  public String getGebDatum() {
    return gebDatum;
  }

  public String getNachname() {
    return nachname;
  }

  public String getVorname() {
    return vorname;
  }

  // Ende Methoden
} // end of Mitarbeiter

