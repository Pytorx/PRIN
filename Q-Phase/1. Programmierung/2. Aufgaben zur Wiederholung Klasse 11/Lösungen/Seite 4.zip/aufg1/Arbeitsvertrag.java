/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 15.09.2023
 * @author 
 */

public class Arbeitsvertrag {
  
  // Anfang Attribute
  private int id;
  private String taetigkeit;
  private double gehalt;
  // Ende Attribute
  
  public Arbeitsvertrag(int id, String taetigkeit, double gehalt) {
    this.id = id;
    this.taetigkeit = taetigkeit;
    this.gehalt = gehalt;
  }

  // Anfang Methoden
  public int getId() {
    return id;
  }

  public String getTaetigkeit() {
    return taetigkeit;
  }

  public double getGehalt() {
    return gehalt;
  }

  // Ende Methoden
} // end of Arbeitsvertrag

