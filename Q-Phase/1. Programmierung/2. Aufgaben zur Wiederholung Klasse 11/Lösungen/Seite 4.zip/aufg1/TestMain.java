
public class TestMain
{
  public static void main (String args[])
  {
    Mitarbeiter mitarbeiter = new Mitarbeiter(4711, "Melitta", "Jacobs-Dallmayr", null);
    Arbeitsvertrag arbeitsvertrag = new Arbeitsvertrag(4711, "Kaffee kochen", 4000);
    
    System.out.println("++++++++ Attributwerte von Mitarbeiter: ++++++++");
    System.out.println(mitarbeiter.getId());
    System.out.println(mitarbeiter.getVorname());
    System.out.println(mitarbeiter.getNachname());
    System.out.println(mitarbeiter.getGebDatum());
    
    System.out.println("\n++++++++ Attributwerte von Arbeitsvertrag: ++++++++");
    System.out.println(arbeitsvertrag.getId());
    System.out.println(arbeitsvertrag.getTaetigkeit());
    System.out.println(arbeitsvertrag.getGehalt());       
  }
}
