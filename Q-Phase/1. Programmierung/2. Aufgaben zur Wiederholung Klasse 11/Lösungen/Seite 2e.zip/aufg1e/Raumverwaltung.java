public class Raumverwaltung
{
	public static void main (String args[])
	{
		Computerraum cr1 = new Computerraum("A1-16", 28, true, 20);

		System.out.println("Bezeichnung des Raums: " + cr1.getBezeichnung());
		System.out.println("Anzahl Plaetze: " + cr1.getAnzahlPlaetze());
		System.out.println("Waschbecken vorhanden: " + cr1.getWaschbecken());
		System.out.println("Anzahl Computer: " + cr1.getAnzahlPC());

		System.out.println("Haben alle Plaetze einen PC? " + cr1.pruefenAllePlaetzeHabenPC());

		System.out.println("--------------------------------------------------------------");

		Computerraum cr2 = new Computerraum("A1-17", 22, true, 22);
		System.out.println("Bezeichnung des Raums: " + cr2.getBezeichnung());
		System.out.println("Anzahl Plaetze: " + cr2.getAnzahlPlaetze());
		System.out.println("Waschbecken vorhanden: " + cr2.getWaschbecken());
		System.out.println("Anzahl Computer: " + cr2.getAnzahlPC());
		System.out.println("Haben alle Plaetze einen PC? " + cr2.pruefenAllePlaetzeHabenPC());
	}
}
