public class Raumverwaltung
{
	public static void main (String args[])
	{
		Raum r = new Raum("A1-13", 30, false);

		System.out.println("Bezeichnung des Raums: " + r.getBezeichnung());
		System.out.println("Anzahl Plaetze: " + r.getAnzahlPlaetze());
		System.out.println("Waschbecken vorhanden: " + r.getWaschbecken());

		System.out.println(" *** Achtung, �nderungen! ***");

		r.setBezeichnung("A1-14");
		r.setAnzahlPlaetze(28);
		r.setWaschbecken(true);

		System.out.println("Bezeichnung des Raums: " + r.getBezeichnung());
		System.out.println("Anzahl Plaetze: " + r.getAnzahlPlaetze());
		System.out.println("Waschbecken vorhanden: " + r.getWaschbecken());

	}
}
