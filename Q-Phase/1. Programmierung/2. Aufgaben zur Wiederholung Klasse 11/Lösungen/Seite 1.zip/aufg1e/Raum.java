public class Raum
{
	private String bezeichnung;
	private int anzahlPlaetze;
	private boolean waschbecken;

	//1.Konstruktor
	public Raum(String bezeichnung, int anzahlPlaetze, boolean waschbecken)
	{
		this.bezeichnung = bezeichnung;
		this.anzahlPlaetze = anzahlPlaetze;
		this.waschbecken = waschbecken;
	}

	//2.Konstruktor (Raum ist noch leer...)
	public Raum(String bezeichnung)
	{
		this.bezeichnung = bezeichnung;
	}

	public void setBezeichnung(String bezeichnung)
	{
		this.bezeichnung = bezeichnung;
	}

	public void setAnzahlPlaetze(int anzahlPlaetze)
	{
		this.anzahlPlaetze = anzahlPlaetze;
	}

	public void setWaschbecken(boolean waschbecken)
	{
		this.waschbecken = waschbecken;
	}

	public String getBezeichnung()
	{
		return bezeichnung;
	}

	public int getAnzahlPlaetze()
	{
		return anzahlPlaetze;
	}

	public boolean getWaschbecken()
	{
		return waschbecken;
	}
}

/*
	Weitere sinnvolle Attribute:
	- raumbeschreibung (String)
	- beamer (boolean)
	- lehrerPC (boolean)
*/