public class Raumverwaltung
{
	public static void main (String args[])
	{
		Raum r1 = new Raum("A1-13", 30, false);
		Raum r2 = new Raum("A1-17");

		System.out.println("Bezeichnung des Raums: " + r1.getBezeichnung());
		System.out.println("Anzahl Plaetze: " + r1.getAnzahlPlaetze());
		System.out.println("Waschbecken vorhanden: " + r1.getWaschbecken());

		System.out.println("---------------------------------------------");

		System.out.println("Bezeichnung des Raums: " + r2.getBezeichnung());
		System.out.println("Anzahl Plaetze: " + r2.getAnzahlPlaetze());
		System.out.println("Waschbecken vorhanden: " + r2.getWaschbecken());

		/*
			Warum w�rde die nachfolgende Zeile beim Kompilieren eine Fehlermeldung erzeugen?
		   	Raum r3 = new Raum("A1-19", 28);
		*/
	}
}
