public class ArrayVerwaltung
{
    public Kunde suchen(Kunde[] kunden, int kundennummer)
    {
        int links = 0, rechts = kunden.length - 1, mitte;
        Kunde kunde;
        
        while (links <= rechts)
        {            
            mitte = (links + rechts) / 2;  //bei X.5 wird "abgeschnitten" (gleiche Wirkung wie abrunden)

            kunde = kunden[mitte];
            
            if(kunde.getKundennummer() == kundennummer)
            {
               return kunde;
            }

            if(kunde.getKundennummer() > kundennummer)
            {
                rechts = mitte - 1;
            }
                else 
                {
                    links = mitte + 1;
                } 
        }
        
        return null; //Kunde nicht gefunden
    }
}








