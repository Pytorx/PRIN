public class TestMain
{
    public static void main (String args[])
    {
        Kunde k1 = new Kunde(233, "Schroedinger");
        Kunde k2 = new Kunde(235, "Einstein");
        Kunde k3 = new Kunde(236, "Newton");
        Kunde k4 = new Kunde(237, "Heisenberg");
        
        Kunde[] kunden = {k1, k2, k3, k4};
                
        ArrayVerwaltung arrayVerwaltung = new ArrayVerwaltung();
        
        for (int i = 233; i <= 237; i++ ) 
        {
            Kunde kunde = arrayVerwaltung.suchen(kunden, i);
            
            System.out.print("gesuchte Kundennummer: " + i + "     ");
            
            if(kunde != null)
            {            
                System.out.println("Nachname des Kunden: " + kunde.getNachname());    
            }   
                else
                {
                    System.out.println("Kunde existiert nicht!");
                }
        }
    }
}

