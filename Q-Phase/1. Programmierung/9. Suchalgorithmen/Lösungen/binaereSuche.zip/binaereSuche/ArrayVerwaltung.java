public class ArrayVerwaltung
{
    public int suchen(int[] zahlen, int zahl)
    {
        int links = 0, rechts = zahlen.length - 1, mitte;
        
        while (links <= rechts)
        {            
            //mitte = Math.round( (links + rechts) / 2 ); //rundet ab bei X.5
            
            mitte = (links + rechts) / 2;  //bei X.5 wird "abgeschnitten" (gleiche Wirkung wie abrunden)

            if(zahlen[mitte] == zahl)
            {
               return mitte;
            }

            if(zahlen[mitte] > zahl)
            {
                rechts = mitte - 1;
            }
                else 
                {
                    links = mitte + 1;
                } 
        }
        
        return -1; //Fehlercode, Zahl nicht gefunden
    }
}








