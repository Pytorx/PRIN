public class TestMain
{
    public static void main (String args[])
    {
        int[] meineZahlen = {12,14,15,17,18,20,21,22,23,24,26,27,28,29,32};
        
        ArrayVerwaltung arrayVerwaltung = new ArrayVerwaltung();
        
        for (int i = 11; i <= 33; i++ ) 
        {
            System.out.println("gesuchte Zahl: " + i + "   gefundener Index: " + arrayVerwaltung.suchen(meineZahlen, i));
        }  
    }
}

